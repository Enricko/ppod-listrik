<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Tagihan;
use Illuminate\Support\Facades\DB;
use App\Http\Resources\TagihanRes;

class ApiTagihan extends Controller
{
    public function index(Request $request)
    {
        $tagihan = DB::table('tagihans')->join('penggunaans','penggunaans.id_penggunaan','=','tagihans.id_penggunaan')->join('users','users.id','=','tagihans.id');
        if(request()->limit){
            $tagihan = $tagihan->take(request()->limit);
        }
        if(request()->bulan){
            $tagihan = $tagihan->where('bulan',request()->bulan);
        }
        if(request()->tahun){
            $tagihan = $tagihan->where('tahun',request()->tahun);
        }
        $tagihan = $tagihan->where('status',request()->status != null ? request()->status : 'belum_bayar')->get();

        $tagihanCol = TagihanRes::collection($tagihan);
        return response()->json([
            'message' => $tagihan->count() <= 0 ? 'failed' : 'success',
            'status' => $tagihan->count() <= 0 ? 'false' : 'true',
            'data' => $tagihanCol,
            'total'=>$tagihan->count()
        ]);
    }

    public function single($id_tagihan){
        $tagihan = Tagihan::all()->where('id_tagihan',$id_tagihan)->where('status','sudah_bayar');
        $tagihanCol = TagihanRes::collection($tagihan);
        return response()->json([
            'message' => $tagihan->count() <= 0 ? 'failed' : 'success',
            'status' => $tagihan->count() <= 0 ? 'false' : 'true',
            'data' => $tagihanCol,
            'total'=>$tagihan->count()
        ]);
    }
}
