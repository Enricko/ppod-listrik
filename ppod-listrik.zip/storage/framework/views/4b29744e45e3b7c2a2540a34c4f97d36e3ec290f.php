<?php
use \App\Http\Controllers\Pembayarans;
use \App\Http\Controllers\Frontend;
?>

<?php $__env->startSection('title','Pembayaran Table'); ?>
<?php $__env->startSection('content'); ?>
<style>
    .popup-box {
        position: relative;
        width: 0px;
        height: 0px;
        background-color: #37444b;
        border-radius: 25px;
        transition: 0.8s;
        display: flex;
        justify-content: center;
        align-items: center;
    }
    
    .popup-box.content {
        min-width: 400px;
        padding: 40px;
    }
    
    .popup-box.active-popup {
        width: 400px;
        height: 250px;
        transition-delay: 0.3s;
    }
    .toggle-btn{
        width: 35px;
        height: 35px;
        background: #0bcf9c;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        justify-content: center;
        align-items: center;    
        margin-top:20px; 
    }
    .toggle-btn::before{
        content: '+';
        font-size: 1.5em;
        color: #fff;
    }
    .popup-box .content-box{
        min-width: 400px;
        padding: 30px;
        color: #fff;
        opacity: 0;
        transition: 0.5s;
        transform: scale(0);
    }
    .popup-box.active-popup .content-box {
        opacity: 1;
        transition-delay: 0.5s;
        transform: scale(1);
    }
    .toggle-btn.active-popup {
        transform: rotate(135deg);
        background: #ff5a57;
        transition: 0.8s;
    }
    
    .info-box {
        display: flex;
        margin: 4px 4px 4px 6px;
        width: 100%;
        align-items: center;
    }
    
    h6.info-box-title {
        display: inline-block;
        width: 120px;
        color: #fff;
        font-size: 15px;
        line-height: 44px;
        font-weight: 500;
        text-transform: uppercase;
    }
    h6.info-box-subtitle {
        font-weight: 500;
        display: inline-block;
        color: #707070;
        font-size: 20px;
        word-wrap: break-word;
        width: 60%;
    }
    </style>
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800"><?php echo $__env->yieldContent('title'); ?></h1>
    <p class="mb-4">
    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">DataTables Example
            </h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>ID Tagihan</th>
                            <th>Name Pengguna</th>
                            <th>Bulan</th>
                            <th>Tahun</th>
                            <th>Total Penggunaan & Harga</th>
                            <th>Biaya Admin</th>
                            <th>Confirm/Last Payment</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $no = 1;
                        ?>
                        <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($row->id_tagihan); ?></td>
                            <td><div class="mb-1">
                                <?php echo e($row->name); ?>

                            </div>
                            <div class="popup-box" id="popup-box<?php echo e($row->id_tagihan); ?>">
                                <div class="content-box">
                                    <div class="info-box">
                                        <h6 class="info-box-title">Name  </h6>
                                        <h6 class="info-box-subtitle"><?php echo e(ucfirst($row->name)); ?></h6>
                                    </div>
                                    <div class="info-box">
                                        <h6 class="info-box-title">Email  </h6>
                                        <h6 class="info-box-subtitle"><?php echo e($row->email); ?> </h6>
                                    </div>
                                    <div class="info-box">
                                        <h6 class="info-box-title">Nomor Kwh  </h6>
                                        <h6 class="info-box-subtitle"><?php echo e($row->nomor_kwh); ?> </h6>
                                    </div>
                                    <div class="info-box">
                                        <h6 class="info-box-title">Nomor Kwh  </h6>
                                        <h6 class="info-box-subtitle"><?php echo e($row->id_tarif == 1 ? 'Rp.1.352' : 'Rp.1.467'); ?> </h6>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-center">
                                <div class="toggle-btn" id="toggle-btn<?php echo e($row->id_tagihan); ?>"></div>
                            </div>
                            <script>
                                let toggleBtn<?php echo e($row->id_tagihan); ?> = document.querySelector('#toggle-btn<?php echo e($row->id_tagihan); ?>');
                                let popupBox<?php echo e($row->id_tagihan); ?> = document.querySelector('#popup-box<?php echo e($row->id_tagihan); ?>');
                                toggleBtn<?php echo e($row->id_tagihan); ?>.onclick = function() {
                                    popupBox<?php echo e($row->id_tagihan); ?>.classList.toggle('active-popup')
                                    toggleBtn<?php echo e($row->id_tagihan); ?>.classList.toggle('active-popup')
                                }
                            </script></td>
                            <td><?php echo e($row->bulan); ?></td>
                            <td><?php echo e($row->tahun); ?></td>
                            <td><?php echo e(Frontend::digits($row->jumlah_meter).' KWH'); ?> = Rp.<?php echo e(Frontend::digits($row->jumlah_meter * ($row->id_tarif == 1 ? 1352 : 1467))); ?></td>
                            <td>Rp.<?php echo e(number_format($row->biaya_admin)); ?></td>
                            <td>
                            <?php
                                $Date = Pembayarans::keliru_1day($row->paid_in);
                                $Ago = Pembayarans::get_time_ago($row->paid_in);
                            ?>
                            <?php if($Date >= 86400): ?>
                            <p style="width:120px;"><?php echo e($Ago); ?></p>                               
                            <?php else: ?>
                                <?php echo e($Ago); ?><br>
                                <a href="/<?php echo e(Auth::user()->id_level == 2 ? 'admin' : 'bank'); ?>/pembayaran/keliru/<?php echo e($row->id_tagihan); ?>/<?php echo e($row->paid_in); ?>" class="btn btn-warning" onclick="return confirm('Apa anda yakin?')">Keliru</a>
                            <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.include.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\ppod_listrik\resources\views/admin/pages/pembayaran/pembayaran.blade.php ENDPATH**/ ?>