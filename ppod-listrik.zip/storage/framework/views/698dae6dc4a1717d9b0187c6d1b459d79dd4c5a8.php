<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PPOB Listrik</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="<?php echo e(asset('css')); ?>/app.css">
</head>
<body class="bg-gradient-primary">
    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg" style="margin-top:140px;">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-3"></div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Welcome&nbsp;<?php echo e(Auth::user()->name); ?></h1>
                                        <p style="font-size:18px;">Tagihan Listrik Anda</p>
                                        <?php if(empty($penggunaan->meter_akhir) && empty($penggunaan->meter_awal)): ?>
                                        <p>Belum Ada Tagihan</p>
                                        <?php else: ?>
                                        <p><?php echo e($penggunaan->meter_akhir - $penggunaan->meter_awal.' KWH'); ?> = <?php echo e('Rp.'.number_format(($penggunaan->meter_akhir - $penggunaan->meter_awal) * $tarif->tarif_perkwh)); ?></p>
                                        <p style="margin-top:15px;"><span style="font-size:18px;">Bayar Melalui : </span> 
                                            <a href="/bayar/bca" class="btn btn-outline-primary"><img src="<?php echo e(asset('images')); ?>/font/bca.png" alt="" style="width:50px;"></a>
                                        </p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="float-right">
                                    <a class="btn btn-outline-danger m-2" href="<?php echo e(route('logout')); ?>"
                                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>
                                    
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\PPOB_listrik\resources\views/frontend/index.blade.php ENDPATH**/ ?>