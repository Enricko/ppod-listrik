<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PPOB Listrik</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="<?php echo e(asset('css')); ?>/app.css">
    <style>
        h1,h2,h3,h4,h5,h6{
            color:black;
        }
        .divider{
            border-top: 3px double #8c8b8b;
        }
    </style>
</head>
<body class="bg-gradient-primary">
    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">
            <div class="card o-hidden border-0 shadow-lg" style="margin-top:140px;margin-bottom:140px;">
                <div class="card-body p-0">
                    <!-- Nested Row within Card Body -->
                    <div class="row">
                        <div class="p-5" style="width:700px;">
                            <h2>PPOD Listrik</h2>
                            <br>
                            <h4>Payment BCA</h4>
                            <hr class="divider">
                            <div class="row">
                                <div class="col-lg-4">
                                    <h5>No Rekening</h5>
                                    <p>0192832234</p>
                                    <p><span class="text-danger">Jangan lupa kirim pesan</span><br><?php echo e(Auth::user()->name); ?> Sudah bayar</p>
                                    <br>
                                </div>
                                <div class="col-lg-4"></div>
                                <div class="col-lg-4 text-right">
                                    <h5>Pay To</h5>
                                    <p>PPOD Listrik</p>
                                    <br>
                                    <h5>Payment Method</h5>
                                    <p>BCA M-Banking</p>
                                </div>
                            </div>
                            <h6> <?php echo e($penggunaan->bulan.'/'.$penggunaan->tahun); ?></h6>
                            <table class="table table-bordered table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Barang</th>
                                        <th>Harga</th>
                                    </tr>
                                </thead>
                                <tbody class="text-center">
                                    <tr>
                                        <td><?php echo e($penggunaan->meter_akhir - $penggunaan->meter_awal.' KWH'); ?></td>
                                        <td><?php echo e('Rp.'.number_format(($penggunaan->meter_akhir - $penggunaan->meter_awal) * $tarif->tarif_perkwh)); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Biaya Admin</td>
                                        <td>RP. 5.000</td>
                                    </tr>
                                    <tr class="text-dark" style="font-weight:700;">
                                        <td>TOTAL</td>
                                        <td><?php echo e('Rp.'.number_format(($penggunaan->meter_akhir - $penggunaan->meter_awal) * $tarif->tarif_perkwh + 5000)); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                            <div class="float-right no-print">
                                <a href="" class="btn btn-outline-secondary" onclick="window.print()">Print</a>
                            </div>
                            <div class="no-print">
                                <p class="text-danger">Jika ada masalah hubungi melalui WA</p>
                                <a href="https://api.whatsapp.com/send?phone=088704688709" class="btn btn-outline-success">Whatsapp</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\PPOB_listrik\resources\views/bayar/bca.blade.php ENDPATH**/ ?>