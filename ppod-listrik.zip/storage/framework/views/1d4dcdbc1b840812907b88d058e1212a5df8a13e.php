<?php
    use \App\models\Pembayaran;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Laporan</title>
    
    <link href="<?php echo e(asset('sb-admin')); ?>/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('sb-admin')); ?>/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <style>
        hr.divider-laporan {
    border-top: 3px double #8c8b8b;
}
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="d-flex justify-content-center">
            <h1>Laporan Bulan <?php echo e($bulan); ?> | Tahun <?php echo e($tahun); ?></h1>
        </div>
        <div class="text-center mt-5">
            <div class="d-flex justify-content-between">
                <h5 class="font-weight-bold">Total Transaksi</h5>
                <h5>Rp.<?php echo e(number_format(Pembayaran::pembayaran_bulan($bulan,$tahun,'pembayarans.total_bayar'))); ?></h5>
            </div>
            <hr class="divider-laporan">
            <div class="d-flex justify-content-between mt-4">
                <h5 class="font-weight-bold">Total Biaya Admin</h5>
                <h5>Rp.<?php echo e(number_format(Pembayaran::pembayaran_bulan($bulan,$tahun,'pembayarans.biaya_admin'))); ?></h5>
            </div>
            <hr class="divider-laporan">
            <div class="d-flex justify-content-between mt-4">
                <h5 class="font-weight-bold">Total KWH</h5>
                <h5><?php echo e(number_format(Pembayaran::pembayaran_bulan($bulan,$tahun,'tagihans.jumlah_meter'))); ?> KWH</h5>
            </div>
            <hr class="divider-laporan">
            <div class="d-flex justify-content-between mt-4">
                <h5 class="font-weight-bold">Total Transaksi</h5>
                <h5><?php echo e(number_format(Pembayaran::pembayaran_bulan_count($bulan,$tahun,'tagihans.jumlah_meter'))); ?> <i class="fas fa-users"></i></h5>
            </div>
            <hr class="divider-laporan">
            <div class="d-flex justify-content-between mt-4">
                <h5 class="font-weight-bold">Total Transaksi di Banding Bulan Lalu %</h5>
                <?php
                    $bulan_persen = ($bulan == '1' ? "12" : $bulan - 1);
                ?>
                <h5>
                    <i class="fas fa-angle-double-<?php echo e(((Pembayaran::pembayaran_bulan($bulan,$tahun,'pembayarans.total_bayar') - Pembayaran::pembayaran_bulan($bulan_persen,$tahun,'pembayarans.total_bayar') && Pembayaran::pembayaran_bulan ($bulan_persen,$tahun,'pembayarans.total_bayar'))  == 0 ? '0' : ((Pembayaran::pembayaran_bulan($bulan,$tahun,'pembayarans.total_bayar') - Pembayaran::pembayaran_bulan( $bulan_persen,$tahun,'pembayarans.total_bayar'))/ Pembayaran::pembayaran_bulan($bulan_persen,$tahun,'pembayarans.total_bayar')) * 100) < 0 ? 'down' : 'up'); ?>" style='color: <?php echo e(((Pembayaran::pembayaran_bulan($bulan,$tahun,'pembayarans.total_bayar') - Pembayaran::pembayaran_bulan($bulan_persen,$tahun,'pembayarans.total_bayar') && Pembayaran::pembayaran_bulan ($bulan_persen,$tahun,'pembayarans.total_bayar'))  == 0 ? '0' : ((Pembayaran::pembayaran_bulan($bulan,$tahun,'pembayarans.total_bayar') - Pembayaran::pembayaran_bulan( $bulan_persen,$tahun,'pembayarans.total_bayar'))/ Pembayaran::pembayaran_bulan($bulan_persen,$tahun,'pembayarans.total_bayar')) * 100) < 0 ? 'red' : 'green'); ?>;'></i>
                    
                    <?php echo e(number_format((Pembayaran::pembayaran_bulan($bulan,$tahun,'pembayarans.total_bayar') - Pembayaran::pembayaran_bulan($bulan_persen,$tahun,'pembayarans.total_bayar') && Pembayaran::pembayaran_bulan ($bulan_persen,$tahun,'pembayarans.total_bayar'))  == 0 ? '0' : ((Pembayaran::pembayaran_bulan($bulan,$tahun,'pembayarans.total_bayar') - Pembayaran::pembayaran_bulan( $bulan_persen,$tahun,'pembayarans.total_bayar'))/ Pembayaran::pembayaran_bulan($bulan_persen,$tahun,'pembayarans.total_bayar')) * 100)); ?> %</h5>
            </div>
            <hr class="divider-laporan">
            <div class="d-flex justify-content-between mt-4">
                <h5 class="font-weight-bold">Total Biaya Admin di Banding Bulan Lalu %</h5>
                
                <h5><?php echo e(number_format((Pembayaran::pembayaran_bulan($bulan,$tahun,'pembayarans.biaya_admin') - Pembayaran::pembayaran_bulan($bulan_persen,$tahun,'pembayarans.biaya_admin') && Pembayaran::pembayaran_bulan($bulan_persen,$tahun,'pembayarans.biaya_admin')) == 0 ? '0' : ((Pembayaran::pembayaran_bulan($bulan,$tahun,'pembayarans.biaya_admin') - Pembayaran::pembayaran_bulan($bulan_persen,$tahun,'pembayarans.biaya_admin')) / Pembayaran::pembayaran_bulan($bulan_persen,$tahun,'pembayarans.biaya_admin')) * 100)); ?> %</h5>
            </div>
            <hr class="divider-laporan">
        </div>
    </div>
</body>
</html><?php /**PATH D:\laragon\www\ppod_listrik\resources\views/admin/laporan.blade.php ENDPATH**/ ?>